export { default } from './WorkInputPage';
